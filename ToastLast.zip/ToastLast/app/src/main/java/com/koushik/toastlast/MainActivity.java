package com.koushik.toastlast;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    Runnable toastShowRunnable,toastHideRunnable;
    Handler mHandler=new Handler();
    EditText et;
    long toastdu=10;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et=findViewById(R.id.insec);

         toastShowRunnable = new Runnable() {
            public void run() {
                handleShow();
            }
        };

         toastHideRunnable = new Runnable() {
            public void run() {
                handleHide();
            }
        };



    }

    public void onclick(View view) {


            try {


                toastdu=1000*Integer.parseInt(et.getText().toString());
            }
            catch (Exception e)
            {
                et.setError("not a valid input showing it for 10 sec");
            //    Toast.makeText(getApplicationContext(),"Input is not valid" ,Toast.LENGTH_SHORT).show();
                toastdu=toastdu*1000;

            }

            handleHide();
            customview();
            show();




    }


    public void show() {

        //runOnUiThread(toastShowRunnable);

        mHandler.post(toastShowRunnable);
        //The duration that you want
        mHandler.postDelayed(toastHideRunnable, toastdu);

    }





    public void handleShow() {

        mWindowManager.addView(mLayout, params);
    }

    public void handleHide() {
        if (mLayout != null) {
            if (mLayout.getParent() != null) {
                mWindowManager.removeView(mLayout);
            }
            mLayout = null;
        }
    }








        WindowManager mWindowManager;
        View mLayout;
    WindowManager.LayoutParams params;

    public void customview ()
        {
            mWindowManager = (WindowManager)MainActivity.this.getSystemService(WINDOW_SERVICE);
            LayoutInflater layoutInflater = (LayoutInflater) MainActivity.this.getSystemService(MainActivity.this.LAYOUT_INFLATER_SERVICE);
            mLayout = layoutInflater.inflate(R.layout.custom_toast_main, null);

//Initialisation




            params = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                    PixelFormat.TRANSLUCENT);
            params.format = PixelFormat.TRANSLUCENT;
            params.windowAnimations = android.R.style.Animation_Toast;
            params.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
            params.gravity = Gravity.BOTTOM;



        }


    }

